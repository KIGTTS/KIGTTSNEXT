local function typed(kind, data)
  data.type = "com.kigtts.plugin.api." .. kind
  return data
end

local function text(key, values)
  return host.t("catalog." .. key, values or {}, key)
end

local function action(id, label, symbol)
  return {id = id, label = text(label), icon = "NONE", symbol = symbol}
end

local function actions(items) return typed("PageBlock.Actions", {actions = items}) end
local function notice(key) return typed("PageBlock.Notice", {text = text(key)}) end
local function block(kind, data) return typed("PageBlock." .. kind, data) end
local function page(id, label, blocks, list, search)
  return {id = id, title = text(label), blocks = blocks, management = list, search = search}
end

local categories = {
  {"catalog-ui", "ui", "widgets"}, {"catalog-lists", "lists", "view_list"},
  {"catalog-feedback", "feedback", "chat_bubble"}, {"catalog-media", "media", "photo_library"},
  {"catalog-chat", "chat", "forum"}, {"catalog-host", "host", "extension"},
  {"catalog-quick-web", "quick_web", "language"}, {"catalog-audio", "audio", "graphic_eq"}
}

local function append(pages)
  local index = {}
  for _, item in ipairs(categories) do
    index[#index + 1] = {id = item[1], title = text(item[2]), subtitle = text(item[2] .. "_hint"),
      group = text("sections"), icon = "INFO", symbol = item[3], primaryAction = item[1]}
  end
  pages[#pages + 1] = page("main", "title", {block("Text", {text = host.t("summary", {}, "API 38")})},
    {id = "catalog-index", items = index, emptyText = text("empty")})

  local selection = host.data.read("catalog/choice.txt")
  local on = host.data.read("catalog/enabled.txt") == "true"
  local options = {action("catalog-choice-a", "option_a"), action("catalog-choice-b", "option_b")}
  local selected = selection == "b" and options[2].id or options[1].id
  local value = math.max(0, math.min(100, tonumber(host.data.read("catalog/slider.txt")) or 35))
  local artwork = {path = host.asset.path("catalog/welcome.webp")}
  local query = host.data.read("catalog/search.txt")
  local rows = {
    {id = "buttons", title = text("ui"), subtitle = text("ui_hint"), image = artwork, primaryAction = "catalog-ui"},
    {id = "media", title = text("media"), subtitle = text("media_hint"), icon = "IMAGE", primaryAction = "catalog-media"},
    {id = "switch", title = text("toggle"), subtitle = text("toggle_hint"), icon = "SETTINGS",
      toggle = {checked = on, action = "catalog-toggle"}}
  }
  local results = {}
  for _, row in ipairs(rows) do
    if #query == 0 or row.title:lower():find(query:lower(), 1, true) then results[#results + 1] = row end
  end

  pages[#pages + 1] = page("catalog-ui", "ui", {
    block("Group", {title = text("form"), children = {
      block("Toggle", {title = text("toggle"), summary = text("toggle_hint"), checked = on, actionId = "catalog-toggle"}),
      block("Choice", {title = text("segmented"), options = options, selected = selected}),
      block("Select", {title = text("select"), options = options, selected = selected}),
      block("Slider", {control = {title = text("slider"), actionId = "catalog-slider", value = value, min = 0, max = 100, steps = 19, suffix = "%"}}),
      block("Input", {title = text("input"), value = host.data.read("catalog/name.txt"), actionId = "catalog-input",
        trailingAction = action("catalog-reset-name", "clear", "close")})
    }}),
    block("Group", {title = text("more"), collapsible = true, initiallyExpanded = false,
      children = {block("Text", {text = text("form_hint")})}}),
    block("StrokeGuide", {title = text("stroke"), instruction = text("stroke_hint"),
      points = {{x = .15, y = .22}, {x = .52, y = .7}, {x = .86, y = .22}}}),
    actions({action("controls", "controls", "tune")})
  })
  pages[#pages + 1] = page("catalog-lists", "lists", {notice("lists_hint"),
    actions({action("catalog-search", "search", "search")})}, {id = "catalog-list", items = rows, emptyText = text("empty")})
  pages[#pages + 1] = page("catalog-search", "search", {notice(#results == 0 and "empty" or "lists_hint")},
    #results > 0 and {id = "catalog-results", items = results, emptyText = text("empty")} or nil,
    {query = query, actionId = "catalog-query", placeholder = text("search")})
  pages[#pages + 1] = page("catalog-feedback", "feedback", {
    notice("feedback_hint"),
    actions({action("catalog-message", "message"), action("catalog-dialog", "dialog"), action("catalog-menu", "menu"),
      action("catalog-confirm", "confirm"), action("catalog-input", "input")})
  })
  pages[#pages + 1] = page("catalog-media", "media", {
    block("Markdown", {text = text("markdown")}),
    block("Gallery", {images = {{resource = artwork, description = text("media"), width = 512, height = 512}}}),
    actions({action("files", "files"), action("catalog-import", "import"), action("catalog-export", "export"),
      action("catalog-photo", "camera"), action("catalog-art", "artwork")})
  })
  local messages = {{id = "welcome", role = "ASSISTANT", text = text("chat_hint")}}
  local last = host.data.read("catalog/echo.txt")
  if #last > 0 then
    messages[#messages + 1] = {id = "question", role = "USER", text = last}
    messages[#messages + 1] = {id = "answer", role = "ASSISTANT", text = text("echo", {value = last})}
  end
  pages[#pages + 1] = page("catalog-chat", "chat", {block("Chat", {messages = messages,
    sendAction = "catalog-chat-send", stopAction = "catalog-chat-clear", conversationId = "local-echo",
    placeholder = text("chat_input"), controls = {{title = text("chat_model"), kind = "MODEL", selected = "local",
      options = {{action = "catalog-message", label = text("chat_model"), value = "local"}}}}})})

  local original = function(id) return {id = id, label = host.t(id, {}, id), icon = "NONE"} end
  local function action_group(title, rows)
    return block("Group", {title = text(title), children = {actions(rows)}})
  end
  pages[#pages + 1] = page("catalog-host", "host", {notice("host_hint"),
    action_group("host_actions", {original("run"), original("network"), original("overlay"), original("notify"),
      original("notify-off"), original("quick-pick")}),
    action_group("subtitle_actions", {original("led"), original("led-off"), original("appearance"), original("appearance-off"),
      original("chrome"), original("chrome-off"), original("listen"), original("listen-off")})})
  pages[#pages + 1] = page("catalog-quick-web", "quick_web", {notice("quick_web_hint"),
    action_group("web_actions", {action("browser", "preview", "language"), action("catalog-add-web", "add_web", "add")})})
  pages[#pages + 1] = page("catalog-audio", "audio", {notice("audio_demo"),
    action_group("test_actions", {original("run"), original("export")})})
  return pages
end

return {append = append, text = text, action = action, typed = typed, categories = categories}
