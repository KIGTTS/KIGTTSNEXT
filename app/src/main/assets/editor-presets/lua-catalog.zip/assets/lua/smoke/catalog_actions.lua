local catalog = host.module("smoke.catalog")
local text = catalog.text
local action = catalog.action
local function outcome(kind, fields)
  return {sdk = catalog.typed("PluginOutcome." .. kind, fields or {})}
end
local function message(key) return outcome("Message", {text = text(key)}) end
local function open(id) return outcome("OpenPage", {pageId = id}) end

local function failure(reply)
  return outcome("Message", {text = reply.message or text("unavailable")})
end

local group_id = "77a2fcd9-b167-48f6-8f8a-50b9df8921c6"
local entry_id = "dda77073-826e-40e7-bc5d-b18e1a31b010"

-- Only runs after the host's confirmation button is selected.
local function add_web()
  local group = host.quick({type = "query", limit = 1, includeContent = false})
  if group.type ~= "snapshot" then return failure(group) end
  local exists = false
  for _, item in ipairs(group.value.groups) do if item.id == group_id then exists = true end end
  if exists then
    local offset = 0
    repeat
      local sample = host.quick({type = "query", groupId = group_id, revision = group.value.revision,
        offset = offset, limit = 20, includeContent = false})
      if sample.type ~= "snapshot" then return failure(sample) end
      for _, entry in ipairs(sample.value.entries) do
        if entry.id == entry_id then return message("exists") end
      end
      offset = sample.value.nextOffset
    until not offset
  end

  local media = host.quick({type = "publish-page", root = {path = "assets/web"},
    mainPage = "index.html", name = text("web_name"), network = false})
  if media.type ~= "media" then return failure(media) end
  local edits = {}
  if not exists then edits[#edits + 1] = {type = "group.put", group = {id = group_id, name = text("title"), icon = "LIST"}} end
  edits[#edits + 1] = {type = "entry.put", entry = {id = entry_id, groupId = group_id, title = text("web_name"),
    text = text("web_name"), kind = "PAGE", mediaId = media.value.id, autoPlay = false, audioPolicy = "SILENT"}}
  local transaction = host.quick({type = "prepare", transactionId = "catalog-web-" .. media.value.id,
    revision = group.value.revision, edits = edits})
  if transaction.type ~= "prepared" then return failure(transaction) end
  local token = transaction.value.token
  if transaction.value.requiresConfirmation then
    local review = host.quick({type = "open-ui", target = "REVIEW", id = token})
    if review.type == "ui-opened" then return outcome("NoAction") end
    return failure(review)
  end
  local saved = host.quick({type = "commit", token = token})
  if saved.type == "applied" then return message("added") end
  return failure(saved)
end

local function save(key, value, limit)
  local last = math.min(#value, limit)
  -- Keep a complete UTF-8 prefix when the input crosses the byte budget.
  while last > 0 and last < #value do
    local following = value:byte(last + 1)
    if following < 128 or following >= 192 then break end
    last = last - 1
  end
  host.data.write("catalog/" .. key .. ".txt", value:sub(1, last))
  return outcome("RefreshUi")
end

local function execute(id, inputs)
  for _, row in ipairs(catalog.categories) do if id == row[1] then return open(id) end end
  if id == "catalog-search" then return open(id) end
  if id == "catalog-query" then return save("search", inputs.value or "", 32) end
  if id == "catalog-toggle" then return save("enabled", inputs.checked == "true" and "true" or "false", 5) end
  if id == "catalog-choice-a" or id == "catalog-choice-b" then return save("choice", id:sub(-1), 1) end
  if id == "catalog-slider" then return save("slider", tostring(math.max(0, math.min(100, tonumber(inputs.value) or 35))), 16) end
  if id == "catalog-input" then
    return outcome("TextInput", {title = text("input"), actionId = "catalog-name", initialValue = host.data.read("catalog/name.txt")})
  end
  if id == "catalog-name" or id == "catalog-reset-name" then return save("name", inputs.value or "", 32) end
  if id == "catalog-chat-send" then return save("echo", inputs.text or inputs.value or "", 120) end
  if id == "catalog-chat-clear" then return save("echo", "", 120) end
  if id == "catalog-message" or id == "catalog-confirmed" then return message("done") end
  if id == "catalog-dialog" then return outcome("Dialog", {title = text("dialog"), text = text("feedback_hint")}) end
  if id == "catalog-menu" then return outcome("Menu", {title = text("menu"),
    items = {action("catalog-message", "message", "info"), action("catalog-dialog", "dialog", "chat_bubble")}}) end
  if id == "catalog-confirm" or id == "catalog-add-web" then
    return outcome("Confirm", {title = text(id == "catalog-add-web" and "add_web" or "confirm"),
      text = text(id == "catalog-add-web" and "add_confirm" or "feedback_hint"),
      action = action(id == "catalog-add-web" and "catalog-publish-web" or "catalog-confirmed", "confirm"),
      cancelLabel = text("cancel")})
  end
  if id == "catalog-publish-web" then return add_web() end
  if id == "catalog-import" then return outcome("ImportResource", {title = text("import"), directory = "catalog/imports",
    actionId = "catalog-file-received", mimeTypes = {"text/plain"}}) end
  if id == "catalog-photo" then return outcome("CapturePhoto", {title = text("camera"), directory = "catalog/photos", actionId = "catalog-file-received"}) end
  if id == "catalog-art" then return outcome("SelectArtwork", {request = {library = "POLAROIDS", title = text("artwork"),
    directory = "catalog/art", actionId = "catalog-file-received"}}) end
  if id == "catalog-file-received" then return message("received") end
  if id == "catalog-export" then return outcome("ExportResource", {title = text("export"),
    resource = {path = host.asset.path("web/index.html")}, fileName = "quick-text-web-index.html", mimeType = "text/html"}) end
end

return {execute = execute}
