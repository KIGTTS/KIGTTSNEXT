local function value(reply, kind)
  if reply and reply.type == kind then return reply.value or reply end
end

local function result(label, success, reply)
  if success then return label .. ": PASS" end
  return label .. ": UNAVAILABLE — " .. tostring(reply and (reply.code or reply.type) or "unexpected reply")
end

local function app(kind, operation)
  return host.app({type = kind, operation = operation})
end

local function quick_query()
  return host.quick({type = "query", offset = 0, limit = 1, includeContent = false})
end

local function check_draft(broker, snapshot, name, edit)
  if not snapshot then return false end
  local reply = broker({type = "prepare", transactionId = name .. tostring(snapshot.revision),
    revision = snapshot.revision, edits = {edit}})
  local prepared = value(reply, "prepared")
  if not prepared then return false, reply end
  local discarded = broker({type = "discard", token = prepared.token})
  return value(discarded, "discarded"), discarded
end

local function run()
  local results = {}
  local function add(label, success, reply)
    results[#results + 1] = result(label, success, reply)
  end

  local fixture = host.asset.read("fixture.txt")
  host.data.write("round-trip.txt", fixture)
  host.binary.write("round-trip.bin", "S0lHVFRT")
  add("Assets, data, binary, localization", fixture:find("API 38", 1, true)
    and host.data.read("round-trip.txt") == fixture and host.binary.read("round-trip.bin") == "S0lHVFRT"
    and #host.t("title", {}, "") > 0)

  local describe = app("describe")
  local info = value(describe, "data")
  local state = value(app("state"), "data")
  add("Host describe/state", info and info.pluginApi >= 38 and state and state.locale, describe)

  local quick = quick_query()
  local quick_snapshot = value(quick, "snapshot")
  add("Quick text query", value(host.quick({type = "describe"}), "features") and quick_snapshot, quick)
  add("Quick text prepare/discard", check_draft(host.quick, quick_snapshot, "lua-quick-smoke-",
    {type = "group.put", group = {name = "API smoke (discard)"}}))

  local frames = host.stickers({type = "query-frames", limit = 1})
  local albums = host.stickers({type = "query-albums", limit = 1})
  add("Gallery frames and albums", value(host.stickers({type = "describe"}), "features")
    and value(frames, "frames") and frames.total > 0 and value(albums, "albums") and albums.total > 0, frames)
  local gallery = value(host.stickers({type = "query", limit = 1}), "snapshot")
  add("Gallery prepare/discard", check_draft(host.stickers, gallery, "lua-gallery-smoke-",
    {type = "album.put", id = "example.lua-smoke.discard", name = "API smoke (discard)"}))

  local overlay = app("overlay", "status")
  add("Overlay status", value(overlay, "data"), overlay)
  local notifications = app("notifications", "status")
  local notification_status = value(notifications, "data")
  add("Notification status", notification_status and notification_status.enabled ~= nil, notifications)
  add("Synthesis broker", type(host.speech({operation = "providers"})) == "table")
  add("Recognition broker", type(host.recognition({operation = "providers"})) == "table")
  return table.concat(results, "\n")
end

local function optional(id, title)
  local reply
  if id == "overlay" then
    reply = app("overlay", "status")
  elseif id == "network" then
    reply = host.http({url = "https://raw.githubusercontent.com/github/gitignore/main/Android.gitignore", method = "GET"})
    return result(id, reply.status == 200, reply)
  else
    local request = {type = "notifications", id = "api-smoke", operation = "cancel"}
    if id == "notify" then
      request.operation = "post"
      request.notification = {id = "api-smoke", title = title, text = "Lua", kind = "MESSAGE"}
    end
    reply = host.app(request)
  end
  return result(id, value(reply, "data"), reply)
end

return {run = run, optional = optional}
