local function engines()
  if not host.binary then return {} end
  return {
    tts = {voices = {{id = "fixture", name = "Lua PCM fixture", language = "zh-CN"}},
      selectedVoiceId = "fixture", role = "SERVICE", supportsControl = true, managesVoices = true,
      profiles = {realtime = "fixture-v1", prebake = "fixture-v1"}},
    asr = {role = "SERVICE", batch = true, streaming = "SEGMENTED", maxBatchSeconds = 5}
  }
end
local function synthesize(request)
  local fixture = "AABAAIAAwAAAAEAA"
  local chunks = {}
  for index = 1, 256 do chunks[index] = fixture end
  host.binary.write(request.output, table.concat(chunks))
  return {format = {sampleRate = 16000, channels = 1}}
end
local function recognize(request)
  assert(#host.binary.read(request.input, 0, 64) > 0)
  return {text = "Lua · batch PCM ✓"}
end
local function recognize_stream(request)
  if request.eof and request.state == true then
    return {events = {{type = "com.kigtts.plugin.api.RecognitionEvent.Final", result = {text = "Lua · segmented PCM ✓"}}}}
  end
  return {state = request.pcm ~= nil or request.state == true}
end
local function voice_command()
  return {type = "com.kigtts.plugin.api.PluginOutcome.Message", text = "Lua PCM fixture"}
end
return {engines = engines, synthesize = synthesize, recognize = recognize,
  recognize_stream = recognize_stream, voice_command = voice_command}
