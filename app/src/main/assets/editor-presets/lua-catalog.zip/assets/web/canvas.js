(() => {
  'use strict';
  const canvas = document.getElementById('drawing');
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const strokes = [];
  let active = null;
  let frame = 0;
  function draw() {
    frame = 0;
    const bounds = canvas.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    const ratio = Math.min(devicePixelRatio || 1, 3);
    const width = Math.round(bounds.width * ratio);
    const height = Math.round(bounds.height * ratio);
    if (canvas.width !== width) canvas.width = width;
    if (canvas.height !== height) canvas.height = height;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, bounds.width, bounds.height);
    ctx.strokeStyle = ctx.fillStyle = getComputedStyle(canvas).getPropertyValue('--demo-primary').trim();
    ctx.lineCap = ctx.lineJoin = 'round';
    for (const stroke of strokes) {
      const [start, ...rest] = stroke.points;
      ctx.beginPath();
      if (rest.length === 0) {
        ctx.arc(start[0] * bounds.width, start[1] * bounds.height, stroke.width / 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.lineWidth = stroke.width;
        ctx.moveTo(start[0] * bounds.width, start[1] * bounds.height);
        for (const [x, y] of rest) ctx.lineTo(x * bounds.width, y * bounds.height);
        ctx.stroke();
      }
    }
  }
  const invalidate = () => { if (!frame) frame = requestAnimationFrame(draw); };
  function point(event) {
    const rect = canvas.getBoundingClientRect();
    const clamp = (value) => Math.max(0, Math.min(1, value));
    return [clamp((event.clientX - rect.left) / rect.width), clamp((event.clientY - rect.top) / rect.height)];
  }
  canvas.addEventListener('pointerdown', (event) => {
    if (active || !event.isPrimary || event.button !== 0) return;
    active = {id: event.pointerId, width: Number(document.getElementById('stroke-width').value), points: [point(event)]};
    if (strokes.length >= 120) strokes.shift();
    strokes.push(active);
    canvas.setPointerCapture(event.pointerId);
    invalidate();
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!active || active.id !== event.pointerId || active.points.length >= 1800) return;
    active.points.push(point(event));
    invalidate();
  });
  canvas.addEventListener('lostpointercapture', () => { active = null; });
  document.getElementById('erase').onclick = () => { active = null; strokes.length = 0; invalidate(); };
  if (window.ResizeObserver) new ResizeObserver(invalidate).observe(canvas);
  window.addEventListener('resize', invalidate);
  window.addEventListener('catalog-panel-change', invalidate);
  window.addEventListener('kigtts-theme-change', invalidate);
})();
