'use strict';
window.KigttsPageReady = false;
const galleryButtons = document.querySelectorAll('.tabs button');
for (const button of galleryButtons) {
  button.addEventListener('click', () => {
    for (const item of galleryButtons) {
      const selected = item === button;
      item.setAttribute('aria-pressed', String(selected));
      document.getElementById(item.getAttribute('aria-controls')).hidden = !selected;
    }
    window.dispatchEvent(new Event('catalog-panel-change'));
  });
}
const nameField = document.getElementById('sample-name');
const result = document.getElementById('result');
document.getElementById('apply').onclick = () => { result.textContent = nameField.value.trim() || '预览'; };
document.getElementById('clear').onclick = () => { nameField.value = ''; result.textContent = '预览'; };
document.getElementById('accent').onchange = (event) => result.classList.toggle('accent', event.target.checked);
for (const button of document.querySelectorAll('[data-demo-haptic]')) {
  button.addEventListener('click', () => {
    const haptic = window.KigttsUI && window.KigttsUI.haptic;
    const status = document.getElementById('haptic-status');
    if (typeof haptic === 'function') {
      haptic(button.dataset.demoHaptic);
      status.textContent = '已发出触感请求，效果遵循应用设置';
    } else {
      status.textContent = '在 KIGTTS 内打开网页即可体验触感';
    }
  });
}
const presentationStatus = document.getElementById('presentation-status');
async function presentationAction(button, method, args = []) {
  const host = window.KigttsPresentation;
  if (typeof host?.[method] !== 'function') {
    presentationStatus.textContent = '请从支持该接口的 KIGTTS 快捷文本中打开';
    return false;
  }
  button.disabled = true;
  try {
    if ((await host[method](...args))?.ok) return true;
    presentationStatus.textContent = '操作未完成，请检查网页外观权限';
  } catch {
    presentationStatus.textContent = '操作未完成';
  } finally {
    button.disabled = false;
  }
  return false;
}
for (const button of document.querySelectorAll('[data-fade-control]')) {
  button.addEventListener('click', async () => {
    const enable = button.getAttribute('aria-pressed') !== 'true';
    if (await presentationAction(button, 'setControls', [{ [button.dataset.fadeControl]: enable }])) {
      button.setAttribute('aria-pressed', String(enable));
      presentationStatus.textContent = enable ? '闲置时会淡化，触摸后恢复' : '已关闭这组控件的淡化';
    }
  });
}
for (const button of document.querySelectorAll('[data-fullscreen]')) {
  button.addEventListener('click', async () => {
    if (await presentationAction(button, button.dataset.fullscreen)) {
      presentationStatus.textContent = button.dataset.fullscreen === 'requestFullscreen' ? '已进入全屏' : '已退出全屏';
    }
  });
}
window.KigttsPageReady = true;
