'use strict';
window.KigttsPageReady = false;
const galleryButtons = document.querySelectorAll('.tabs button');
for (const button of galleryButtons) {
  button.addEventListener('click', () => {
    for (const item of galleryButtons) {
      const selected = item === button;
      item.setAttribute('aria-pressed', String(selected));
      document.getElementById(item.getAttribute('aria-controls')).hidden = !selected;
    }
    window.dispatchEvent(new Event('catalog-panel-change'));
  });
}
const nameField = document.getElementById('sample-name');
const result = document.getElementById('result');
document.getElementById('apply').onclick = () => { result.textContent = nameField.value.trim() || '预览'; };
document.getElementById('clear').onclick = () => { nameField.value = ''; result.textContent = '预览'; };
document.getElementById('accent').onchange = (event) => result.classList.toggle('accent', event.target.checked);
for (const button of document.querySelectorAll('[data-demo-haptic]')) {
  button.addEventListener('click', () => {
    const haptic = window.KigttsUI && window.KigttsUI.haptic;
    const status = document.getElementById('haptic-status');
    if (typeof haptic === 'function') {
      haptic(button.dataset.demoHaptic);
      status.textContent = '已发出触感请求，效果遵循应用设置';
    } else {
      status.textContent = '在 KIGTTS 内打开网页即可体验触感';
    }
  });
}
window.KigttsPageReady = true;
