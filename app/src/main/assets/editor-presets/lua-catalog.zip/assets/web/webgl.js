(() => {
  'use strict';
  const canvas = document.getElementById('model');
  const fallback = document.getElementById('model-fallback');
  const slider = document.getElementById('yaw');
  const initialYaw = -28;
  let yaw = initialYaw;
  let pitch = 24;
  let pointer;
  let frame = 0;
  let pipeline;
  const gl = canvas.getContext('webgl', { antialias: true, alpha: false });
  if (!gl) { showFallback(true); return; }

  const vertex = `
    attribute vec3 position;
    attribute float shade;
    uniform vec2 angle;
    uniform vec2 fit;
    varying float light;
    void main() {
      float cy = cos(angle.x), sy = sin(angle.x);
      float cx = cos(angle.y), sx = sin(angle.y);
      vec3 r = vec3(position.x*cy + position.z*sy, position.y, -position.x*sy + position.z*cy);
      vec3 p = vec3(r.x, r.y*cx - r.z*sx, r.y*sx + r.z*cx);
      gl_Position = vec4(p.xy * fit * 0.50, p.z * 0.28, 1.0 + p.z * 0.20);
      light = shade;
    }`;
  const fragment = `
    precision mediump float;
    varying float light;
    uniform vec3 accent;
    uniform vec3 container;
    void main() { gl_FragColor = vec4(mix(accent, container, light), 1.0); }`;

  function shader(type, source) {
    const object = gl.createShader(type);
    gl.shaderSource(object, source);
    gl.compileShader(object);
    if (!gl.getShaderParameter(object, gl.COMPILE_STATUS)) {
      const error = gl.getShaderInfoLog(object);
      gl.deleteShader(object);
      throw new Error(error);
    }
    return object;
  }
  function setup() {
    const program = gl.createProgram();
    const vertexShader = shader(gl.VERTEX_SHADER, vertex);
    const fragmentShader = shader(gl.FRAGMENT_SHADER, fragment);
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    gl.deleteShader(vertexShader);
    gl.deleteShader(fragmentShader);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
    const points = [[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]];
    const sides = [[0,1,2,3],[4,5,6,7],[0,3,7,4],[1,5,6,2],[0,1,5,4],[3,2,6,7]];
    const vertices = [];
    sides.forEach((face, index) => {
      for (const corner of [0,1,2,0,2,3]) vertices.push(...points[face[corner]], 0.13 + index * 0.17);
    });
    gl.useProgram(program);
    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, 'position');
    const shade = gl.getAttribLocation(program, 'shade');
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 3, gl.FLOAT, false, 16, 0);
    gl.enableVertexAttribArray(shade);
    gl.vertexAttribPointer(shade, 1, gl.FLOAT, false, 16, 12);
    gl.enable(gl.DEPTH_TEST);
    return Object.fromEntries(['angle', 'fit', 'accent', 'container'].map((name) => [name, gl.getUniformLocation(program, name)]));
  }

  const swatch = document.createElement('canvas');
  swatch.width = swatch.height = 1;
  const colors = swatch.getContext('2d');
  function color(style, property) {
    colors.clearRect(0, 0, 1, 1);
    colors.fillStyle = style.getPropertyValue(property).trim();
    colors.fillRect(0, 0, 1, 1);
    return Array.from(colors.getImageData(0, 0, 1, 1).data.slice(0, 3), (value) => value / 255);
  }
  function draw() {
    frame = 0;
    if (!pipeline || gl.isContextLost()) return;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (!width || !height) return;
    const ratio = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(width * ratio)) canvas.width = Math.round(width * ratio);
    if (canvas.height !== Math.round(height * ratio)) canvas.height = Math.round(height * ratio);
    const style = getComputedStyle(canvas);
    const aspect = width / height;
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(...color(style, '--demo-surface-container-high'), 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniform2f(pipeline.angle, yaw * Math.PI / 180, pitch * Math.PI / 180);
    gl.uniform2f(pipeline.fit, Math.min(1, 1 / aspect), Math.min(1, aspect));
    gl.uniform3fv(pipeline.accent, color(style, '--demo-primary'));
    gl.uniform3fv(pipeline.container, color(style, '--demo-primary-container'));
    gl.drawArrays(gl.TRIANGLES, 0, 36);
  }
  const invalidate = () => { if (!frame) frame = requestAnimationFrame(draw); };
  function showFallback(visible) {
    canvas.hidden = visible;
    fallback.hidden = !visible;
    slider.disabled = visible;
    document.getElementById('reset-model').disabled = visible;
  }
  function initialize() {
    try { pipeline = setup(); showFallback(false); invalidate(); }
    catch (error) { showFallback(true); console.warn('Catalog WebGL:', error.message); }
  }
  canvas.addEventListener('pointerdown', (event) => {
    if (pointer || !event.isPrimary || event.button !== 0) return;
    pointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!pointer || pointer.id !== event.pointerId) return;
    yaw = ((yaw + (event.clientX - pointer.x) * 0.65 + 540) % 360 + 360) % 360 - 180;
    pitch = Math.min(85, Math.max(-85, pitch + (event.clientY - pointer.y) * 0.65));
    pointer.x = event.clientX;
    pointer.y = event.clientY;
    slider.value = yaw;
    invalidate();
  });
  canvas.addEventListener('lostpointercapture', () => { pointer = undefined; });
  canvas.addEventListener('webglcontextlost', (event) => { event.preventDefault(); pipeline = null; showFallback(true); });
  canvas.addEventListener('webglcontextrestored', initialize);
  slider.oninput = () => { yaw = Number(slider.value); invalidate(); };
  document.getElementById('reset-model').onclick = () => { slider.value = yaw = initialYaw; pitch = 24; invalidate(); };
  if (window.ResizeObserver) new ResizeObserver(invalidate).observe(canvas);
  window.addEventListener('resize', invalidate);
  window.addEventListener('catalog-panel-change', invalidate);
  window.addEventListener('kigtts-theme-change', invalidate);
  initialize();
})();
