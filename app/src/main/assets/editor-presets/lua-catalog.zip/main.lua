local checks = host.module("smoke.checks")
local speech = host.module("smoke.speech")
local catalog = host.module("smoke.catalog")
local catalog_actions = host.module("smoke.catalog_actions")
local namespace = "com.kigtts.plugin.api."
local function typed(kind, data)
  data.type = namespace .. kind
  return data
end
local function outcome(kind, fields)
  return {sdk = typed("PluginOutcome." .. kind, fields or {})}
end
local function text(key) return host.t(key, {}, key) end
local function action(id) return {id = id, label = text(id), icon = "NONE"} end
local function actions(ids)
  local items = {}
  for _, id in ipairs(ids) do items[#items + 1] = action(id) end
  return typed("PageBlock.Actions", {actions = items})
end
local function page(id, title, blocks)
  return {id = id, title = text(title), blocks = blocks}
end

local function pages()
  if not host.path then
    -- Source review and the standalone runtime have distinct supported contracts.
    return {{id = "main", title = text("title"), blocks = {{type = "text", text = text("intro")}}}}
  end
  return {sdk = catalog.append({
    page("details", "details", {typed("PageBlock.Markdown", {text = "**API 38** — Lua"}), actions({"back"})}),
    page("browser", "browser", {typed("PageBlock.Browser", {root = {path = host.asset.path("web")}, mainPage = "index.html"})}),
    page("files", "files", {typed("PageBlock.Files", {title = text("files"), directory = "", openAction = "source",
      operationAction = "ignored", items = {{path = "fixture.txt", name = "fixture.txt", directory = false, bytes = 28}}})}),
    page("source", "files", {typed("PageBlock.SourceEditor", {id = "fixture", text = "return 'KIGTTS'", language = "lua",
      saveAction = "ignored", readOnly = true})}),
    page("caption", "listen", {typed("PageBlock.Text", {text = text("intro")}), actions({"listen-off"})})
  })}
end

local function contributions()
  if not host.path then
    return {settingsEntries = {{id = "main", label = text("title"), pageId = "main"}}}
  end
  local menu = {}
  for _, id in ipairs({"led", "led-off", "appearance", "appearance-off", "chrome", "chrome-off", "listen", "listen-off"}) do
    menu[#menu + 1] = {id = id, label = text(id), icon = "INFO", slot = "EDITOR_MENU", presentation = "MENU_ITEM"}
  end
  return {sdk = {actions = menu, automationActions = {"run", "overlay"},
    gestures = {{id = "stroke", label = text("title"), gesture = "SUBTITLE_STROKE"}},
    settingsEntries = {{id = "main", label = catalog.text("title") .. " · Lua", pageId = "main",
      summary = text("summary"), symbol = "fact_check"}}}}
end

local function execute(id, ctx)
  local inputs = ctx.inputs or {}
  local example = catalog_actions.execute(id, inputs)
  if example then return example end
  if id == "run" then
    local report = checks.run()
    host.data.write("report.txt", report)
    return outcome("Dialog", {title = text("title"), text = report})
  elseif id == "controls" then
    return outcome("Controls", {title = text(id), controls = {
      typed("PluginControl.Slider", {title = text("value"), actionId = "value", value = .45}),
      typed("PluginControl.Toggle", {title = text("toggle"), actionId = "toggle", checked = false}),
      typed("PluginControl.Color", {title = text("color"), actionId = "color", value = 4284385220}),
      typed("PluginControl.Choice", {title = text("options"), actionId = "option", selected = "a",
        options = {{id = "a", label = "A"}, {id = "b", label = "B"}}})
    }})
  elseif id == "value" or id == "toggle" or id == "option" or id == "color" then
    host.data.write((id == "toggle" and "switch" or id) .. ".txt", (inputs.value or inputs.checked or ""):sub(1, 256))
    return outcome("NoAction")
  elseif id == "browser" then
    return outcome("OpenPage", {pageId = id})
  elseif id == "back" or id == "details" or id == "files" or id == "source" then
    return outcome("OpenPage", {pageId = id == "back" and "main" or id})
  elseif id == "led" then
    return outcome("SetNativeSubtitleRenderer", {renderer = typed("NativeSubtitleRenderer.Led",
      {dotRows = 16, glow = .25, keepScreenOn = false, quickSwipe = false})})
  elseif id == "led-off" then return outcome("SetNativeSubtitleRenderer")
  elseif id == "appearance" then
    return outcome("SetTemporaryAppearance", {appearance = {themeColor = 4284385220, contrast = "MEDIUM"}})
  elseif id == "appearance-off" then return outcome("SetTemporaryAppearance")
  elseif id == "chrome" then
    return outcome("SetHomeChrome", {presentation = {fadeHeaderWhenIdle = true, fadeDockWhenIdle = true}})
  elseif id == "chrome-off" then return outcome("SetHomeChrome")
  elseif id == "listen" then
    return outcome("SetListeningPanel", {pageId = "caption", replaceContent = false, replaceControls = false})
  elseif id == "listen-off" then return outcome("SetListeningPanel")
  elseif id == "quick-pick" then
    return outcome("SelectQuickText", {title = text(id), actionId = "picked"})
  elseif id == "picked" then
    return outcome("Message", {text = inputs.selectedIds and "Quick text selection callback ✓" or "Quick text selection callback"})
  elseif id == "overlay" or id == "notify" or id == "notify-off" or id == "network" then
    return outcome("Dialog", {title = text(id), text = checks.optional(id, text("title"))})
  elseif id == "export" then
    return outcome("ExportResource", {title = text(id), fileName = "lua-smoke-report.txt", mimeType = "text/plain",
      resource = {path = host.path("report.txt")}})
  elseif id == "stroke" and inputs["gesture.points"] then
    host.data.write("stroke.txt", inputs["gesture.durationMs"] or "0")
  end
  return outcome("NoAction")
end

return {
  contributions = contributions, pages = pages, execute = execute,
  test = function() return {asset = host.asset.read("fixture.txt"):find("API 38", 1, true) ~= nil, locale = text("title")} end,
  engines = speech.engines, synthesize = speech.synthesize, recognize = speech.recognize,
  recognize_stream = speech.recognize_stream, asr_control = function() return true end,
  tts_control = function() end, voice_command = speech.voice_command
}
