KIGTTS API smoke fixture. No external models or dependencies bundled.
