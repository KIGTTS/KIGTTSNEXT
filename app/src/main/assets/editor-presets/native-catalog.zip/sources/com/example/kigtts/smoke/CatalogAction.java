package com.example.kigtts.smoke;

import com.kigtts.plugin.api.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

/** Public examples return outcomes. Only callbacks mutate the sample's own saved state. */
final class CatalogAction {
    private final SmokePlugin plugin;
    private final CatalogPages labels;
    CatalogAction(SmokePlugin plugin, PluginContext context) {
        this.plugin = plugin;
        this.labels = new CatalogPages(plugin, context);
    }
    PluginOutcome execute(String id, Map<String, String> inputs) throws IOException, InterruptedException {
        if (CatalogPages.isRoute(id)) return new PluginOutcome.OpenPage(id);
        String value = inputs.getOrDefault("value", "");
        switch (id) {
            case "catalog-query": return save("search", value, 32);
            case "catalog-toggle": return save("enabled", Boolean.toString(Boolean.parseBoolean(inputs.get("checked"))), 5);
            case "catalog-choice-a": return save("choice", "a", 1);
            case "catalog-choice-b": return save("choice", "b", 1);
            case "catalog-slider": return save("slider", Float.toString(CatalogPages.slider(value)), 16);
            case "catalog-input": return new PluginOutcome.TextInput(labels.text("input"), "catalog-name",
                plugin.read("catalog/name.txt"), false, false);
            case "catalog-name": return save("name", value, 32);
            case "catalog-reset-name": return save("name", "", 32);
            case "catalog-chat-send": return save("echo", inputs.getOrDefault("text", value), 120);
            case "catalog-chat-clear": return save("echo", "", 120);
            case "catalog-message": case "catalog-confirmed": return message("done");
            case "catalog-dialog": return new PluginOutcome.Dialog(labels.text("dialog"), labels.text("feedback_hint"));
            case "catalog-menu": return new PluginOutcome.Menu(labels.text("menu"), Arrays.asList(
                labels.action("catalog-message", "message", "info"), labels.action("catalog-dialog", "dialog", "chat_bubble")));
            case "catalog-confirm": return confirm("confirm", "feedback_hint", "catalog-confirmed");
            case "catalog-add-web": return confirm("add_web", "add_confirm", "catalog-publish-web");
            case "catalog-publish-web": return new QuickWebExample(plugin.environment(), labels).publish();
            case "catalog-import": return new PluginOutcome.ImportResource(labels.text("import"), "catalog/imports",
                "catalog-file-received", false, Collections.singletonList("text/plain"), false);
            case "catalog-photo": return new PluginOutcome.CapturePhoto(labels.text("camera"), "catalog/photos", "catalog-file-received");
            case "catalog-art": return new PluginOutcome.SelectArtwork(new ArtworkSelectionRequest(ArtworkLibrary.POLAROIDS,
                labels.text("artwork"), false, Collections.emptyList(), "catalog-file-received", null, "catalog/art"));
            case "catalog-file-received": return message("received");
            case "catalog-export": return new PluginOutcome.ExportResource(labels.text("export"),
                SmokePlugin.resource("catalog/web/index.html"), "quick-text-web-index.html", "text/html", false);
            default: return null;
        }
    }
    private PluginOutcome confirm(String title, String description, String callback) {
        return new PluginOutcome.Confirm(labels.text(title), labels.text(description),
            labels.action(callback, "confirm", "check"), labels.text("cancel"));
    }
    private PluginOutcome save(String key, String value, int maxLength) throws IOException {
        int end = value.offsetByCodePoints(0, Math.min(maxLength, value.codePointCount(0, value.length())));
        plugin.write("catalog/" + key + ".txt", value.substring(0, end));
        return PluginOutcome.RefreshUi.INSTANCE;
    }
    private PluginOutcome message(String key) {
        return new PluginOutcome.Message(labels.text(key));
    }
}
