package com.example.kigtts.smoke;

import com.kigtts.plugin.api.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** The host renders every page, including the search field and Compose settings controls. */
final class CatalogPages {
    private static final String[][] SECTIONS = {
        {"catalog-ui", "ui", "widgets"}, {"catalog-lists", "lists", "view_list"},
        {"catalog-feedback", "feedback", "chat_bubble"}, {"catalog-media", "media", "photo_library"},
        {"catalog-chat", "chat", "forum"}, {"catalog-host", "host", "extension"},
        {"catalog-quick-web", "quick_web", "language"}, {"catalog-audio", "audio", "graphic_eq"}
    };
    private final SmokePlugin plugin;
    private final PluginContext context;
    CatalogPages(SmokePlugin plugin, PluginContext context) {
        this.plugin = plugin;
        this.context = context;
    }
    static boolean isRoute(String id) {
        if (id.equals("catalog-search")) return true;
        for (String[] section : SECTIONS) if (section[0].equals(id)) return true;
        return false;
    }
    String text(String key) { return plugin.text("catalog." + key, context); }
    PageAction action(String id, String key, String icon) {
        return new PageAction(id, text(key), PluginIcon.NONE, icon);
    }
    private PageBlock.Actions actions(PageAction... items) { return new PageBlock.Actions(Arrays.asList(items)); }
    private PageBlock.Group group(String label, List<PageAction> items) {
        return new PageBlock.Group(text(label), Collections.singletonList(new PageBlock.Actions(items)));
    }
    private PageBlock.Notice notice(String key) { return new PageBlock.Notice(text(key)); }
    private PluginPage simple(String id, String title, PageBlock... blocks) {
        return new PluginPage(id, text(title), Arrays.asList(blocks), null);
    }
    private ManagementItem row(String id, String title, String subtitle, String group, String open, String icon,
                               PluginResource image, ManagementToggle toggle) {
        return new ManagementItem(id, text(title), text(subtitle), PluginIcon.INFO, image, false, false,
            group, open, Collections.emptyList(), toggle, icon);
    }

    PluginPage page(String id) {
        switch (id) {
            case "main": {
                List<ManagementItem> sections = new ArrayList<>();
                for (String[] item : SECTIONS) {
                    sections.add(row(item[0], item[1], item[1] + "_hint", text("title"), item[0], item[2], null, null));
                }
                return new PluginPage(id, text("title"), Collections.emptyList(),
                    new ManagementList("catalog-index", sections, null, text("empty"), Collections.emptyList()));
            }
            case "catalog-ui": return form(id);
            case "catalog-lists": case "catalog-search": return list(id);
            case "catalog-feedback":
                return simple(id, "feedback", notice("feedback_hint"),
                    actions(action("catalog-message", "message", "info"), action("catalog-dialog", "dialog", "chat_bubble"),
                        action("catalog-menu", "menu", "menu"), action("catalog-confirm", "confirm", "check"),
                        action("catalog-input", "input", "edit")));
            case "catalog-media":
                return simple(id, "media", new PageBlock.Markdown(text("markdown"), Collections.emptyMap()),
                    new PageBlock.Gallery(Collections.singletonList(new PageImage(SmokePlugin.resource("catalog/welcome.webp"),
                        text("media"), 512, 512))),
                    actions(action("files", "files", "folder"), action("catalog-import", "import", "upload"),
                        action("catalog-export", "export", "download"), action("catalog-photo", "camera", "photo_camera"),
                        action("catalog-art", "artwork", "photo_library")));
            case "catalog-chat": return chat(id);
            case "catalog-host":
                return simple(id, "host", notice("host_hint"),
                    group("host_actions", plugin.actions(context, "run", "network", "overlay", "notify", "notify-off", "quick-pick")),
                    group("subtitle_actions", plugin.actions(context, "led", "led-off", "appearance", "appearance-off",
                        "chrome", "chrome-off", "listen", "listen-off")));
            case "catalog-quick-web":
                return simple(id, "quick_web", notice("quick_web_hint"),
                    group("web_actions", Arrays.asList(action("browser", "preview", "language"),
                        action("catalog-add-web", "add_web", "add"))));
            case "catalog-audio":
                return simple(id, "audio", notice("audio_demo"), group("test_actions", plugin.actions(context, "run", "export")));
            default: return null;
        }
    }

    private PluginPage form(String id) {
        List<PageAction> options = Arrays.asList(action("catalog-choice-a", "option_a", null),
            action("catalog-choice-b", "option_b", null));
        String selected = "b".equals(plugin.read("catalog/choice.txt")) ? "catalog-choice-b" : "catalog-choice-a";
        boolean enabled = "true".equals(plugin.read("catalog/enabled.txt"));
        List<PageBlock> fields = Arrays.asList(
            new PageBlock.Toggle(text("toggle"), enabled, "catalog-toggle", text("toggle_hint"), PluginIcon.NONE),
            new PageBlock.Choice(text("segmented"), options, selected, PluginIcon.NONE),
            new PageBlock.Select(text("select"), options, selected, PluginIcon.NONE, null),
            new PageBlock.Slider(new PluginControl.Slider(text("slider"), "catalog-slider",
                slider(plugin.read("catalog/slider.txt")), 0, 100, 19, "%")),
            new PageBlock.Input(text("input"), plugin.read("catalog/name.txt"), "catalog-input", false, false,
                PluginIcon.EDIT, null, action("catalog-reset-name", "clear", "close")));
        PageBlock guide = new PageBlock.StrokeGuide(text("stroke"), text("stroke_hint"),
            Arrays.asList(new StrokePoint(.15f, .22f), new StrokePoint(.52f, .7f), new StrokePoint(.86f, .22f)),
            "", null, Collections.emptyList());
        return simple(id, "ui", new PageBlock.Group(text("form"), fields),
            new PageBlock.Group(text("more"), Collections.singletonList(new PageBlock.Text(text("form_hint"), false)), true, false),
            guide, actions(action("controls", "controls", "tune")));
    }

    private PluginPage list(String id) {
        boolean search = id.equals("catalog-search");
        String query = plugin.read("catalog/search.txt");
        List<ManagementItem> items = new ArrayList<>();
        items.add(row("buttons", "ui", "ui_hint", "", "catalog-ui", "widgets", SmokePlugin.resource("catalog/welcome.webp"), null));
        items.add(row("media", "media", "media_hint", "", "catalog-media", "photo_library", null, null));
        items.add(row("switch", "toggle", "toggle_hint", "", null, "toggle_on", null,
            new ManagementToggle("true".equals(plugin.read("catalog/enabled.txt")), "catalog-toggle")));
        if (search) items.removeIf(item -> !item.getTitle().toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)));
        ManagementList list = new ManagementList("catalog-managed", items, null, text("empty"), Collections.emptyList());
        return new PluginPage(id, text(search ? "search" : "lists"), search ? Collections.emptyList() : Arrays.asList(
            notice("lists_hint"), actions(action("catalog-search", "search", "search"))), list, null, null, false,
            null, null, search ? new PluginSearch(query, "catalog-query", text("search")) : null);
    }

    private PluginPage chat(String id) {
        List<ChatMessage> messages = new ArrayList<>();
        messages.add(message("welcome", ChatRole.ASSISTANT, text("chat_hint")));
        String last = plugin.read("catalog/echo.txt");
        if (!last.isEmpty()) {
            messages.add(message("question", ChatRole.USER, last));
            messages.add(message("answer", ChatRole.ASSISTANT,
                plugin.message("catalog.echo", context, Collections.singletonMap("value", last))));
        }
        ChatControl model = new ChatControl(text("chat_model"), Collections.singletonList(
            new ChatOption("catalog-message", text("chat_model"), "local")), "local", ChatControlKind.MODEL);
        return simple(id, "chat", new PageBlock.Chat(messages, "catalog-chat-send", "catalog-chat-clear", false,
            text("chat_input"), "local-echo", Collections.singletonList(model), null, false));
    }
    private static ChatMessage message(String id, ChatRole role, String text) {
        return new ChatMessage(id, role, text, "", ChatMessageState.COMPLETE);
    }
    static float slider(String value) {
        try {
            float number = Float.parseFloat(value);
            return Float.isFinite(number) ? Math.max(0f, Math.min(100f, number)) : 35f;
        } catch (NumberFormatException badInput) {
            return 35f;
        }
    }
}
