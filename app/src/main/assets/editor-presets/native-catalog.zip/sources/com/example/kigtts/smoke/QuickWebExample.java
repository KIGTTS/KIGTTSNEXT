package com.example.kigtts.smoke;

import com.kigtts.plugin.api.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlinx.coroutines.BuildersKt;

/** Publish an offline PAGE card after the user confirms. Updates to unrelated cards are never needed. */
final class QuickWebExample {
    private static final String GROUP = "77a2fcd9-b167-48f6-8f8a-50b9df8921c6";
    private static final String ENTRY = "2e68da66-145c-4fe6-af49-8bad88234f17";
    private final QuickTextBroker broker;
    private final CatalogPages labels;
    QuickWebExample(PluginEnvironment env, CatalogPages labels) {
        this.broker = env.getQuickTextBroker();
        this.labels = labels;
    }

    PluginOutcome publish() throws InterruptedException {
        if (broker == null) return message("unavailable");
        QuickTextReply query = request(new QuickTextCommand.Query(null, 0, 1, null, false));
        if (!(query instanceof QuickTextReply.Snapshot)) return failure(query);
        QuickTextSnapshot snapshot = ((QuickTextReply.Snapshot) query).getValue();
        boolean groupExists = snapshot.getGroups().stream().anyMatch(group -> GROUP.equals(group.getId()));
        if (groupExists) {
            Integer offset = 0;
            while (offset != null) {
                QuickTextReply scan = request(new QuickTextCommand.Query(GROUP, offset, 20, snapshot.getRevision(), false));
                if (!(scan instanceof QuickTextReply.Snapshot)) return failure(scan);
                QuickTextSnapshot group = ((QuickTextReply.Snapshot) scan).getValue();
                if (group.getEntries().stream().anyMatch(entry -> ENTRY.equals(entry.getId()))) return message("exists");
                offset = group.getNextOffset();
            }
        }
        String name = labels.text("web_name");
        QuickTextReply published = request(new QuickTextCommand.PublishPage(SmokePlugin.resource("catalog/web"),
            "index.html", null, name, Collections.emptyList(), false, null));
        if (!(published instanceof QuickTextReply.Media)) return failure(published);
        String mediaId = ((QuickTextReply.Media) published).getValue().getId();

        List<QuickTextEdit> edits = new ArrayList<>();
        if (!groupExists) edits.add(new QuickTextEdit.PutGroup(new QuickGroup(GROUP, labels.text("title"), "LIST")));
        edits.add(new QuickTextEdit.PutEntry(new QuickEntry(ENTRY, GROUP, name, name, QuickCardKind.PAGE, mediaId,
            QuickColorKind.DEFAULT, 0xff00696eL, false, Collections.emptyList(), false, QuickAudioPolicy.SILENT,
            Collections.emptyMap())));
        QuickTextReply prepared = request(new QuickTextCommand.Prepare("catalog-web-" + mediaId, snapshot.getRevision(), edits));
        if (!(prepared instanceof QuickTextReply.Prepared)) return failure(prepared);
        QuickBatchPreview preview = ((QuickTextReply.Prepared) prepared).getValue();
        if (preview.getRequiresConfirmation()) {
            QuickTextReply review = request(new QuickTextCommand.OpenUi(QuickUiTarget.REVIEW, preview.getToken()));
            return review instanceof QuickTextReply.UiOpened ? PluginOutcome.NoAction.INSTANCE : failure(review);
        }
        QuickTextReply committed = request(new QuickTextCommand.Commit(preview.getToken()));
        return committed instanceof QuickTextReply.Applied ? message("added") : failure(committed);
    }

    private QuickTextReply request(QuickTextCommand command) throws InterruptedException {
        return BuildersKt.runBlocking(EmptyCoroutineContext.INSTANCE, (scope, result) -> broker.request(command, result));
    }
    private PluginOutcome failure(QuickTextReply reply) {
        if (reply instanceof QuickTextReply.Failure) return new PluginOutcome.Message(((QuickTextReply.Failure) reply).getMessage());
        return message("unavailable");
    }
    private PluginOutcome message(String key) { return new PluginOutcome.Message(labels.text(key)); }
}
