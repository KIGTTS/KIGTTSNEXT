package com.example.kigtts.smoke;

import com.kigtts.plugin.api.*;
import java.util.Collections;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;

final class SmokeAudio {
    private static final AudioFormat FORMAT = new AudioFormat(16000, 1);
    private static final TtsInfo VOICE = new TtsInfo(EngineAvailability.READY,
        Collections.singletonList(new VoiceInfo("fixture", "Java PCM fixture", "zh-CN", "", false, null, null)),
        4000, TtsRole.SERVICE, "fixture", false, true, Collections.emptyList(), true,
        new TtsProfileVersions("fixture-v1", "fixture-v1"));

    static final TtsEngine TTS = new TtsEngine() {
        @Override public TtsInfo getInfo() { return VOICE; }
        @Override public Flow<SynthesisEvent> synthesize(TtsRequest request) {
            byte[] pcm = new byte[4096];
            for (int i = 0; i < pcm.length / 2; i++) {
                int sample = (int) (2048 * Math.sin(i * 2 * Math.PI * 440 / FORMAT.getSampleRate()));
                pcm[i * 2] = (byte) sample;
                pcm[i * 2 + 1] = (byte) (sample >> 8);
            }
            return FlowKt.flowOf(SynthesisEvent.Started.INSTANCE,
                new SynthesisEvent.Audio(new PcmAudio(pcm, FORMAT.getSampleRate(), FORMAT.getChannels())),
                new SynthesisEvent.Finished(null));
        }
    };

    static final AsrEngine ASR = new ControlledAsrEngine() {
        @Override public AsrInfo getInfo() { return new AsrInfo(FORMAT, true, StreamingKind.SEGMENTED, EngineAvailability.READY, 5, AsrRole.SERVICE); }
        @Override public Object recognize(PcmAudio audio, RecognitionConfig config, Continuation<? super RecognitionResult> continuation) {
            if (audio.getBytes().length == 0) throw new IllegalArgumentException("Missing PCM");
            return new RecognitionResult("Java · batch PCM ✓", false);
        }
        @Override public Flow<RecognitionEvent> recognizeStream(Flow<PcmAudio> audio, RecognitionConfig config) {
            return FlowKt.map(audio, (pcm, continuation) ->
                new RecognitionEvent.Final(new RecognitionResult("Java · segmented PCM ✓", false)));
        }
        @Override public Object control(AsrControl command, Continuation<? super Boolean> continuation) { return true; }
    };
    private SmokeAudio() {}
}
