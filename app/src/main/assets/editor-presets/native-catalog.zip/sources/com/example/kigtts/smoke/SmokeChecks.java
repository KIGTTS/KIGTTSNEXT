package com.example.kigtts.smoke;

import com.kigtts.plugin.api.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;

final class SmokeChecks {
    private final PluginEnvironment environment;
    SmokeChecks(PluginEnvironment environment) { this.environment = environment; }

    String run() {
        return String.join("\n", Arrays.asList(
            check("Assets, data, binary", this::storage),
            check("Host describe/state", () -> {
                require(app(AppCommand.Describe.INSTANCE).getValue().containsKey("pluginApi"));
                require(app(AppCommand.State.INSTANCE).getValue().containsKey("locale"));
            }),
            check("Quick text query", () -> {
                require(quick(QuickTextCommand.Describe.INSTANCE) instanceof QuickTextReply.Features);
                quickSnapshot();
            }),
            check("Quick text prepare/discard", this::quickDraft),
            check("Gallery frames and albums", () -> {
                require(sticker(StickerCommand.Describe.INSTANCE) instanceof StickerReply.Features);
                require(expect(sticker(new StickerCommand.QueryFrames(0, 1, null)), StickerReply.Frames.class).getTotal() > 0);
                require(expect(sticker(new StickerCommand.QueryAlbums(0, 1, null)), StickerReply.Albums.class).getTotal() > 0);
            }),
            check("Gallery prepare/discard", this::galleryDraft),
            check("Overlay status", () -> app(new AppCommand.Overlay("status", null, null, null))),
            check("Notification status", () -> require(app(new AppCommand.Notifications("status", null, null)).getValue().containsKey("enabled"))),
            check("Synthesis broker", () -> require(environment.getSpeechBroker().providers() != null)),
            check("Recognition broker", () -> require(environment.getRecognitionBroker().providers() != null))
        ));
    }

    String optional(String id, String title) {
        return check(id, () -> {
            if (id.equals("overlay")) {
                app(new AppCommand.Overlay("status", null, null, null));
            } else if (id.equals("network")) {
                File file = await((scope, done) -> environment.download(
                    "https://raw.githubusercontent.com/github/gitignore/main/Android.gitignore", "tmp/android.gitignore", null, done));
                require(file.isFile() && file.length() > 0 && file.length() < 32768);
            } else if (id.equals("notify-off")) {
                app(new AppCommand.Notifications("cancel", null, "api-smoke"));
            } else {
                PluginNotification notification = PluginSnapshotKt.getPluginJson().decodeFromString(PluginNotification.Companion.serializer(),
                    "{\"id\":\"api-smoke\",\"kind\":\"MESSAGE\",\"text\":\"Java\",\"title\":"
                    + kotlinx.serialization.json.JsonElementKt.JsonPrimitive(title) + "}");
                app(new AppCommand.Notifications("post", notification, null));
            }
        });
    }

    private void storage() throws Exception {
        File asset = new File(environment.getAssets(), "fixture.txt");
        byte[] bytes = Files.readAllBytes(asset.toPath());
        require(new String(bytes, StandardCharsets.UTF_8).contains("API 38"));
        File roundTrip = environment.getStorage().file("tmp/round-trip.bin");
        Files.createDirectories(roundTrip.getParentFile().toPath());
        Files.write(roundTrip.toPath(), bytes);
        require(Arrays.equals(bytes, Files.readAllBytes(roundTrip.toPath())));
    }

    private QuickTextSnapshot quickSnapshot() throws Exception {
        return expect(quick(new QuickTextCommand.Query(null, 0, 1, null, false)), QuickTextReply.Snapshot.class).getValue();
    }
    private void quickDraft() throws Exception {
        long revision = quickSnapshot().getRevision();
        QuickGroup group = new QuickGroup(UUID.randomUUID().toString(), "API smoke (discard)", "LIST");
        QuickTextReply.Prepared reply = expect(quick(new QuickTextCommand.Prepare(UUID.randomUUID().toString(), revision,
            Collections.singletonList(new QuickTextEdit.PutGroup(group)))), QuickTextReply.Prepared.class);
        expect(quick(new QuickTextCommand.Discard(reply.getValue().getToken())), QuickTextReply.Discarded.class);
    }
    private void galleryDraft() throws Exception {
        long revision = expect(sticker(new StickerCommand.Query(StickerScope.ALL, null, 0, 1, null)), StickerReply.Snapshot.class).getValue().getRevision();
        StickerReply.Prepared reply = expect(sticker(new StickerCommand.Prepare(UUID.randomUUID().toString(), revision,
            Collections.singletonList(new StickerEdit.PutAlbum("example.native-smoke.discard", "API smoke (discard)")))), StickerReply.Prepared.class);
        expect(sticker(new StickerCommand.Discard(reply.getValue().getToken())), StickerReply.Discarded.class);
    }
    private AppReply.Data app(AppCommand command) throws Exception {
        return expect(await((scope, done) -> environment.getAppBroker().request(command, done)), AppReply.Data.class);
    }
    private QuickTextReply quick(QuickTextCommand command) throws Exception {
        return await((scope, done) -> environment.getQuickTextBroker().request(command, done));
    }
    private StickerReply sticker(StickerCommand command) throws Exception {
        return await((scope, done) -> environment.getStickerBroker().request(command, done));
    }
    private static <T> T await(Function2<CoroutineScope, Continuation<? super T>, Object> call) throws InterruptedException {
        return BuildersKt.runBlocking(EmptyCoroutineContext.INSTANCE, call);
    }
    private static <T> T expect(Object reply, Class<T> expected) {
        if (expected.isInstance(reply)) return expected.cast(reply);
        if (reply instanceof AppReply.Failure) throw new IllegalStateException(((AppReply.Failure) reply).getCode());
        if (reply instanceof QuickTextReply.Failure) throw new IllegalStateException(((QuickTextReply.Failure) reply).getCode().name());
        if (reply instanceof StickerReply.Failure) throw new IllegalStateException(((StickerReply.Failure) reply).getCode().name());
        throw new IllegalStateException(reply == null ? "no reply" : reply.getClass().getSimpleName());
    }
    private static void require(boolean value) { if (!value) throw new IllegalStateException("unexpected reply"); }
    private static String check(String name, Check action) {
        try { action.run(); return name + ": PASS"; }
        catch (Exception e) { return name + ": UNAVAILABLE — " + e.getClass().getSimpleName() + ": " + e.getMessage(); }
    }
    private interface Check { void run() throws Exception; }
}
