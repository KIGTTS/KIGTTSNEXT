package com.example.kigtts.smoke;

import com.kigtts.plugin.api.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import kotlin.Unit;
import kotlin.coroutines.Continuation;

public final class SmokePlugin implements KigPlugin {
    private static final String ID = "example.native-smoke";
    private static final String[] HOME_ACTIONS = {"led", "led-off", "appearance", "appearance-off", "chrome", "chrome-off", "listen", "listen-off"};
    private static final PluginLocalization LOCALE = new PluginLocalization("zh-CN",
        Arrays.asList("zh-CN", "zh-CN-x-casual", "en", "ja", "ko"));
    private PluginEnvironment environment;
    private PluginStrings strings;

    @Override public PluginDescriptor getDescriptor() {
        return new PluginDescriptor(ID, "原生插件组件目录", "预览组件和验证插件接口", "0.2.2", 38, false, "MIT", Collections.emptyList());
    }
    @Override public PluginLocalization getLocalization() { return LOCALE; }
    @Override public TtsEngine getTts() { return SmokeAudio.TTS; }
    @Override public AsrEngine getAsr() { return SmokeAudio.ASR; }
    @Override public VoiceManager getVoiceManager() {
        return (command, continuation) -> new PluginOutcome.Message("Native PCM fixture");
    }
    @Override public Object attach(PluginEnvironment env, Continuation<? super Unit> continuation) {
        environment = env;
        strings = PluginStrings.Companion.fromAssets(env.getAssets(), LOCALE.getDefaultLocale());
        File web = env.getStorage().directory("catalog/web");
        File[] samples = new File(env.getAssets(), "web").listFiles();
        if (samples == null) throw new IllegalStateException("Web sample assets missing");
        for (File sample : samples) {
            try {
                Files.copy(sample.toPath(), new File(web, sample.getName()).toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            } catch (java.io.IOException error) {
                throw new IllegalStateException("Cannot stage " + sample.getName(), error);
            }
        }
        try {
            Files.copy(new File(env.getAssets(), "catalog/welcome.webp").toPath(),
                env.getStorage().file("catalog/welcome.webp").toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (java.io.IOException error) {
            throw new IllegalStateException("Cannot stage the catalog image", error);
        }
        return Unit.INSTANCE;
    }
    PluginEnvironment environment() { return environment; }
    String text(String key, PluginContext context) { return message(key, context, Collections.emptyMap()); }
    String message(String key, PluginContext context, java.util.Map<String, String> values) {
        return strings.text(key, context.getLocale(), values, key);
    }
    private PageAction action(String id, PluginContext context) {
        return new PageAction(id, text(id, context), PluginIcon.NONE);
    }
    List<PageAction> actions(PluginContext context, String... ids) {
        java.util.ArrayList<PageAction> items = new java.util.ArrayList<>();
        for (String id : ids) items.add(action(id, context));
        return items;
    }
    @Override public PluginContributions contributions(PluginContext context) {
        java.util.ArrayList<UiAction> menu = new java.util.ArrayList<>();
        for (String id : HOME_ACTIONS) {
            menu.add(new UiAction(id, text(id, context), UiSlot.EDITOR_MENU, PluginIcon.INFO, UiPresentation.MENU_ITEM, 0, UiButtonStyle.ICON_TEXT));
        }
        return new PluginContributions(menu, Collections.emptyList(),
            Collections.singletonList(new GestureAction("stroke", text("title", context), PluginGesture.SUBTITLE_STROKE)),
            Arrays.asList("run", "overlay"),
            Collections.singletonList(new SettingsEntry("main", text("catalog.title", context) + " · Java", "main",
                PluginIcon.NONE, "extensions", "", text("summary", context), 0, "fact_check")),
            Collections.emptyList(), null);
    }

    @Override public PluginPage page(String id, PluginContext context) {
        PluginPage catalog = new CatalogPages(this, context).page(id);
        if (catalog != null) return catalog;
        List<PageBlock> blocks;
        String title = id;
        switch (id) {
            case "details":
                blocks = Arrays.asList(new PageBlock.Markdown("**API 38** — Java", Collections.emptyMap()),
                    new PageBlock.Actions(actions(context, "back")));
                break;
            case "browser":
                blocks = Collections.singletonList(new PageBlock.Browser(resource("catalog/web"), "index.html", null, false, Collections.emptyList()));
                break;
            case "files":
                blocks = Collections.singletonList(new PageBlock.Files(text(id, context),
                    Collections.singletonList(new PluginFileItem("fixture.txt", "fixture.txt", false, 28)),
                    "", "source", "ignored", null, null, null));
                break;
            case "source":
                title = "files";
                blocks = Collections.singletonList(new PageBlock.SourceEditor("fixture", "// KIGTTS API smoke", "ignored", "java", true));
                break;
            case "caption":
                title = "listen";
                blocks = Arrays.asList(new PageBlock.Text(text("intro", context), false), new PageBlock.Actions(actions(context, "listen-off")));
                break;
            default: return null;
        }
        return new PluginPage(id, text(title, context), blocks, null);
    }

    @Override public Object execute(String id, PluginContext context, Continuation<? super PluginOutcome> continuation) {
        try {
            if (id.startsWith("catalog-")) {
                PluginOutcome catalog = new CatalogAction(this, context).execute(id, context.getInputs());
                if (catalog != null) return catalog;
            }
            switch (id) {
                case "run":
                    String report = new SmokeChecks(environment).run();
                    write("report.txt", report);
                    return new PluginOutcome.Dialog(text("title", context), report);
                case "controls": return controls(context);
                case "toggle": case "value": case "option": case "color":
                    String value = context.getInputs().getOrDefault("value", context.getInputs().getOrDefault("checked", ""));
                    write(id.equals("toggle") ? "switch.txt" : id + ".txt", value.substring(0, Math.min(value.length(), 256)));
                    return PluginOutcome.NoAction.INSTANCE;
                case "browser": case "details": case "files": case "source": return new PluginOutcome.OpenPage(id);
                case "back": return new PluginOutcome.OpenPage("main");
                case "led": return wireOutcome("SetNativeSubtitleRenderer",
                    "\"renderer\":{\"type\":\"com.kigtts.plugin.api.NativeSubtitleRenderer.Led\",\"dotRows\":16,\"glow\":0.25,\"keepScreenOn\":false,\"quickSwipe\":false}");
                case "led-off": return wireOutcome("SetNativeSubtitleRenderer", "");
                case "appearance": return new PluginOutcome.SetTemporaryAppearance(new AppearancePatch(4284385220L, null, null, null, null, AppearanceContrast.MEDIUM));
                case "appearance-off": return new PluginOutcome.SetTemporaryAppearance(null);
                case "chrome": return new PluginOutcome.SetHomeChrome(new HomeChromePresentation(true, true));
                case "chrome-off": return new PluginOutcome.SetHomeChrome(null);
                case "listen": return new PluginOutcome.SetListeningPanel("caption", false, false, false);
                case "listen-off": return new PluginOutcome.SetListeningPanel(null, false, false, false);
                case "quick-pick": return new PluginOutcome.SelectQuickText(text(id, context), QuickTextSelectionMode.SINGLE,
                    Collections.emptyList(), "picked", null);
                case "picked": return new PluginOutcome.Message("Quick text selection callback");
                case "overlay": case "notify": case "notify-off": case "network":
                    return new PluginOutcome.Dialog(text(id, context), new SmokeChecks(environment).optional(id, text("title", context)));
                case "export": return new PluginOutcome.ExportResource(text(id, context), resource("report.txt"), "native-smoke-report.txt", "text/plain", false);
                case "stroke":
                    if (context.getInputs().containsKey("gesture.points")) write("stroke.txt", context.getInputs().getOrDefault("gesture.durationMs", "0"));
                    return PluginOutcome.NoAction.INSTANCE;
                default: return PluginOutcome.NoAction.INSTANCE;
            }
        } catch (Exception error) {
            return new PluginOutcome.Message("Smoke: " + error.getClass().getSimpleName() + ": " + error.getMessage());
        }
    }
    private PluginOutcome controls(PluginContext context) {
        return new PluginOutcome.Controls(text("controls", context), Arrays.asList(
            new PluginControl.Slider(text("value", context), "value", .45f, 0f, 1f, 0, ""),
            new PluginControl.Toggle(text("toggle", context), "toggle", false),
            new PluginControl.Color(text("color", context), "color", 4284385220L),
            new PluginControl.Choice(text("options", context), "option",
                Arrays.asList(new PluginControlOption("a", "A"), new PluginControlOption("b", "B")), "a", PluginChoiceStyle.SEGMENTED)), null);
    }
    private PluginOutcome wireOutcome(String name, String fields) {
        String suffix = fields.isEmpty() ? "" : "," + fields;
        return PluginSnapshotKt.getPluginJson().decodeFromString(PluginOutcome.Companion.serializer(),
            "{\"type\":\"com.kigtts.plugin.api.PluginOutcome." + name + "\"" + suffix + "}");
    }
    void write(String path, String value) throws java.io.IOException {
        File file = environment.getStorage().file(path);
        Files.createDirectories(file.getParentFile().toPath());
        Files.write(file.toPath(), value.getBytes(StandardCharsets.UTF_8));
    }
    String read(String path) {
        File file = environment.getStorage().file(path);
        try { return file.isFile() ? new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8) : ""; }
        catch (java.io.IOException error) { return ""; }
    }
    static PluginResource resource(String path) { return new PluginResource(path, null, false); }
}
